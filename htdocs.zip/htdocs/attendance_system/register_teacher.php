<?php
include 'db_connect.php';

if (isset($_POST['register_teacher'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // เข้ารหัสรหัสผ่าน
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // สร้าง hash สำหรับ Teacher
    $hash = hash('sha256', $username . time()); // ใช้ username และเวลาปัจจุบันเพื่อสร้าง hash ที่ไม่ซ้ำกัน

    // ตรวจสอบว่า username ซ้ำหรือไม่
    $check_query = "SELECT * FROM teachers WHERE username = '$username'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        $error = "Username already exists!";
    } else {
        // เพิ่ม Teacher ในฐานข้อมูล
        $insert_query = "INSERT INTO teachers (hash, username, password) 
                         VALUES ('$hash', '$username', '$hashed_password')";
        if ($conn->query($insert_query)) {
            $success = "Teacher added successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <a href="index.php">back</a>
    <title>Register Teacher</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Register New Teacher</h1>
        <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

        <form action="register_teacher.php" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <button type="submit" name="register_teacher">Register</button>
            
        </form>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Attendance Management System</title>
    <a href="logout.php">Logout</a>
</head>
<body>
    <h1>Behavior score Management System</h1>
    <div class="form-container">
        <form action="process.php" method="post">
            
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required>
            
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required>

            <button type="submit" name="add_student">Add Student</button>
        </form>
    </div>
    <div class="table-container">
        <h2>Student List</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>

                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Score</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            
<?php
include 'db_connect.php';

$query = "SELECT * FROM students";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['hash']}</td>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['score']}</td>
            <td><a href='edit.php?hash={$row['hash']}'>Edit</a></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No students found</td></tr>";
}
?>
<?php
session_start();
if (!isset($_SESSION['teacher_hash'])) {
    header("Location: login.php");
    exit();
}
?>


                

            </tbody>
        </table>
    </div>
</body>
</html>

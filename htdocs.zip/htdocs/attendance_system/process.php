<?php
include 'db_connect.php';

if (isset($_POST['add_student'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    // สร้าง hash จากข้อมูลนักเรียน
    $hash = hash('sha256', $first_name . $last_name);

    // ตรวจสอบว่า hash ซ้ำหรือไม่
    $check_query = "SELECT * FROM students WHERE hash = '$hash'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        echo "Error: Duplicate student.";
    } else {
        // เพิ่มนักเรียนในฐานข้อมูล
        $query = "INSERT INTO students (hash, first_name, last_name) 
                  VALUES ('$hash', '$first_name', '$last_name')";
        if ($conn->query($query)) {
            header("Location: index.php");
        } else {
            echo "Error: " . $conn->error;
        }
    }
}


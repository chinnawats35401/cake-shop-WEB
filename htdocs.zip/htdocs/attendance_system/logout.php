<?php
session_start();
unset($_SESSION['teacher_hash']); // ลบข้อมูล hash ของครู
session_destroy();
header("Location: login.php");
exit();
?>

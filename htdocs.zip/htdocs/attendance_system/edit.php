<?php
session_start();
include 'db_connect.php'; // คอนเนคกับฐานข้อมูล

// ตรวจสอบการล็อกอินของ Teacher โดยใช้ Hash
if (!isset($_SESSION['teacher_hash'])) {
    header("Location: login.php"); // หาก Teacher ยังไม่ได้ล็อกอินจะถูกส่งไปยังหน้า login
    exit();
}

// ถ้ามีการส่งข้อมูลมาให้ทำการอัปเดตคะแนน
if (isset($_POST['update_student'])) {
    $student_hash = $_POST['student_hash']; // ใช้ hash แทน student_hash
    $score = $_POST['score'];  // คะแนนที่ต้องการอัปเดต

    // ตรวจสอบว่า hash นี้มีอยู่ในฐานข้อมูลหรือไม่
    $query = "SELECT * FROM students WHERE hash = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_hash); // ใช้ hash เป็นเงื่อนไข
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // อัปเดตคะแนนของ Student
        $update_query = "UPDATE students SET score = ? WHERE hash = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ds", $score, $student_hash); // อัปเดตคะแนนด้วย hash
        if ($update_stmt->execute()) {
            $success = "Student's score updated successfully!";
        } else {
            $error = "Error updating the student's score.";
        }
    } else {
        $error = "Student not found.";
    }
}

// ดึงข้อมูลของ Student ทั้งหมดเพื่อแสดงในตาราง
$query_students = "SELECT * FROM students";
$students_result = $conn->query($query_students);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student Behavior score</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <a href="index.php">back</a>
    <h1>Edit Behavior score</h1>
    <!-- แสดงข้อความสำเร็จหรือผิดพลาด -->
    <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <!-- ฟอร์มอัปเดตคะแนนของ Student -->
    <form action="edit.php" method="post">
        <label for="student_hash">Student Hash:</label>
        <input type="text" name="student_hash" id="student_hash" required placeholder="Enter Student Hash">

        <label for="score">Score:</label>
        <input type="number" name="score" id="score" required placeholder="Enter New Score">

        <button type="submit" name="update_student">Update Score</button>
    </form>

    <!-- ตารางแสดงรายชื่อ Student -->
    <h2>Student List</h2>
    <table>
        <thead>
            <tr>
                <th>Student Hash</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Score</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($students_result->num_rows > 0) {
                while ($student = $students_result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . $student['hash'] . "</td>
                        <td>" . $student['first_name'] . "</td>
                        <td>" . $student['last_name'] . "</td>
                        <td>" . $student['score'] . "</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No students found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>
